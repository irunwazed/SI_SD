 // Material Select Initialization
$(document).ready(function() {
    $(".mdb-select").material_select();
});